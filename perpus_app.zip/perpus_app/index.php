
      <?php
      include 'config/layout.php';
      ?>

   <div class="p-4 sm:ml-64">
      <div class="p-4 mt-14">
         <h1>Dasboard</h1>
      </div>
   </div>